﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(decimal fuelQuantity, decimal fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            this.FuelConsumption += 1.6M;
        }

        
        public override void Refuel(decimal liters)
        {
            this.FuelQuantity += liters*0.95M;
        }
        public override string ToString()
        {
            return $"{this.GetType().Name}: {FuelQuantity:F2}";
        }
    }
}
