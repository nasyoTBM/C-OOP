﻿using System;
using System.Linq;

namespace Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine()
                .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            string[] truckInfo = Console.ReadLine()
                .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            Car car = new Car(decimal.Parse(carInfo[1]), decimal.Parse(carInfo[2]));
            Truck truck = new Truck(decimal.Parse(truckInfo[1]), decimal.Parse(truckInfo[2]));

            int lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                string[] input = Console.ReadLine()
                    .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                switch (input[1].ToLower())
                {
                    case "car":
                        if (input[0].ToLower() == "drive")
                        {
                            car.Drive(decimal.Parse(input[2]));
                        }
                        else if (input[0].ToLower() == "refuel")
                        {
                            car.Refuel(decimal.Parse(input[2]));
                        }
                        break;
                    case "truck":
                        if (input[0].ToLower() == "drive")
                        {
                            truck.Drive(decimal.Parse(input[2]));
                        }
                        else if (input[0].ToLower() == "refuel")
                        {
                            truck.Refuel(decimal.Parse(input[2]));
                        }
                        break;
                    default:
                        break;
                }
            }
            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());



        }
    }
}
