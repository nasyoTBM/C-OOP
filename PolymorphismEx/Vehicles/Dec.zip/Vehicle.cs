﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        private decimal fuelQuantity;
        private decimal fuelConsumption;
        

        public decimal FuelQuantity
        {
            get { return fuelQuantity; }
            set { fuelQuantity = value; }
        }

        
        public decimal FuelConsumption
        {
            get { return fuelConsumption; }
            set { fuelConsumption = value; }
        }
        public Vehicle(decimal fuelQuantity, decimal fuelConsumption)
        {
            this.fuelQuantity = fuelQuantity;
            this.fuelConsumption = fuelConsumption;
        }
        public void Drive(decimal km)
        {
            decimal litersToDrive = km * FuelConsumption;
            if (this.FuelQuantity >= litersToDrive)
            {
                this.FuelQuantity -= litersToDrive;
                Console.WriteLine($"{this.GetType().Name} travelled {km} km");
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} needs refueling");
            }
        }
        public abstract void Refuel(decimal liters);
    }
}
