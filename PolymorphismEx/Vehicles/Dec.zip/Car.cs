﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(decimal fuelQuantity, decimal fuelConsumption)
            :base(fuelQuantity,fuelConsumption)
        {
            this.FuelConsumption += 0.9M;
        }
        

        public override void Refuel(decimal liters)
        {
            this.FuelQuantity += liters;
        }
        public override string ToString()
        {
            return $"{this.GetType().Name}: {FuelQuantity:F2}";
        }
    }
}
