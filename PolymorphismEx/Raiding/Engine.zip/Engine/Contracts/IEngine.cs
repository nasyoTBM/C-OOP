﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Engine.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
