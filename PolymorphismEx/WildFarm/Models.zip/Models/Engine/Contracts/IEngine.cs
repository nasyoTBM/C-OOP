﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Engine.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
