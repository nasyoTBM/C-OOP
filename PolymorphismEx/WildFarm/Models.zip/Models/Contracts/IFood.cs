﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace WildFarm.Models.Contracts
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
