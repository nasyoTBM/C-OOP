﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonsInfo
{
    public class Person
    {

        public Person(string firstName,string lastName,int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }
        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            private set { firstName = value; }
        }
        public string  LastName { get; private set; }
        public int Age { get; private set; }
        public override string ToString()
        {
            return $"{this.FirstName} {this.LastName} is {this.Age} years old.";
        }
    }
}
