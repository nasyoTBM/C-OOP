﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars
{
    interface IElectricCar
    {
        public int Battery { get;}
    }
}
