﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using OnlineShop.Models.Products.Computers;

namespace OnlineShop.Models.SubComputers
{
    public class DesktopComputer : Computer
    {
        public const double OVERALLPERFORMANCE = 15;

        public DesktopComputer(int id, string manufacturer, string model, decimal price)
            : base(id, manufacturer, model, price,OVERALLPERFORMANCE)
        {
            
        }
        


    }
}
